#ifndef JUEGO_H
#define	JUEGO_H
#include "azar.h"
#include "casilla.h"
#include "colores.h"
#include "imprimir.h"
#include "tiempo.h"

typedef struct{
	int estado;
	int valor;
}tcasilla;

typedef struct{
	int nfil;
	int ncol;
	int numero_bombas;
	tcasilla mat[N][M];
	int tapadas;
	int marcadas;
	int tiempo;
	int emoji;
	int inicializado;
}ttablero;		

int menu_inicializar();
void tablero_jugar();
void tablero_finalizar();
void inicializar_tablero();
int fin_juego();


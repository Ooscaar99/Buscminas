#ifndef IMPRIMIR_H
#define	IMPRIMIR_H
#include "azar.h"
#include "casilla.h"
#include "colores.h"
#include "tiempo.h"


typedef struct{
	int estado;
	int valor;
}tcasilla;

typedef struct{
	int nfil;
	int ncol;
	int numero_bombas;
	tcasilla mat[N][M];
	int tapadas;
	int marcadas;
	int tiempo;
	int emoji;
	int inicializado;
}ttablero;		

int menu_tablero(opcion);
int emoji();
int numero_contadas();
int mostrar_bombas();
void mostrar_tablero_fin();
void mostrar_tablero();

#endif

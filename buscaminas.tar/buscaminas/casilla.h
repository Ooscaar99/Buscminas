#ifndef CASILLA_H
#define	CASILLA_H
#include "azar.h"

typedef struct{
	int estado;
	int valor;
}tcasilla;

int casilla_inicializar();
int cambiar_estado();

#endif

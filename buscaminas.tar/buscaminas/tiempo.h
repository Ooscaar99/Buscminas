#ifndef TIEMPO_H 
#define	TIEMPO_H

void empieza_tiempo();

/*
 * int tiempo_transcurrido();
 * Devuelve en segundos el tiempo transcurrido desde que se invoco a
 * empieza_tiempo();
 */
int tiempo_transcurrido();

#endif	/* TIEMPO_H */

